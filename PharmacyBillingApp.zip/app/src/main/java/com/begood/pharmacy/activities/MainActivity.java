
package com.begood.pharmacy.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.begood.pharmacy.R;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.salesBtn).setOnClickListener(v -> startActivity(new Intent(this, SalesActivity.class)));
        findViewById(R.id.inventoryBtn).setOnClickListener(v -> startActivity(new Intent(this, InventoryActivity.class)));
    }
}
